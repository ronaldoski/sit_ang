import React from 'react';
import Card from './Card';
import Img from './img';
import ksvg from './2k.svg'
const SecondPage: React.FC = () => {
  return (
    <div>

      <header>   
      <h1>Bienvenue sur la page d'accueil</h1>

      <h3> a propos de moi</h3>

     

      </header>

<body>
<p>competence</p>
<Img i={ksvg} />


<Card 
                Titre="presentation" 
               text='hi, my name is bilal im informatician student'
            />

            <Card 



Titre='objectif'

text='objectif   ijhbli'
/>

</body>

<footer>



</footer>

    </div>
  );
};

export default SecondPage;
