import React from 'react';

const contactPage: React.FC = () => {
  return (
    <div>

      <header>
      <h1>Bienvenue sur la page de contact</h1>


     

      


      </header>
    </div>
  );
};

export default contactPage;
