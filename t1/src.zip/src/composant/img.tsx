import React from 'react';
import styles from './Card.module.css';

type ImgProps = {
    i: string | { default: string };
};

const Img: React.FC<ImgProps> = ({ i }) => {
  const imgSrc = typeof i === 'string' ? i : i.default;

  return (
    <div className={styles.imageContainer}>
      <img src={imgSrc} alt="" className={styles.image} />
    </div>
  );
};

export default Img;