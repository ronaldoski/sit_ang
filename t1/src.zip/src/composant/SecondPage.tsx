import React from 'react';

const SecondPage: React.FC = () => {
  return (
    <div>
      <h1>Bienvenue sur la seconde page</h1>
    </div>
  );
};

export default SecondPage;
